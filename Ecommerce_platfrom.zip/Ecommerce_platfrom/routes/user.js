import express from 'express'
const router = express.Router()
import userRegistration from '../controller/user/signup.js'
import userLogin from '../controller/user/login.js'
import changePassword from '../controller/user/changepassword.js'
import checkUserAuth from '../middleware/auth-middleware.js'
import forgetPassword from '../controller/user/forgetpassword.js'
import userPasswordReset from '../controller/user/resetpassword.js'

//Auth-Middleware
// router.use('/api/changepassword',checkUserAuth)

//Public Route
router.post('/api/register',userRegistration)
router.post('/api/login',userLogin)
router.post('/api/forget-Password',forgetPassword)
router.post('/api/reset-password/:id/:token',userPasswordReset)

//Protected Route
router.post('/api/changepassword',checkUserAuth,changePassword)

export default router