import User from "../../models/User.js";
import bcrypt from "bcrypt";

//User Signup
const userRegistration = async (req, res) => {
  const { name, email, age, password, password_confirmation, address } = req.body;
  const user = await User.findOne({ email: email });
  if (user) {
    res.send({ status: "failed", message: "Email Already Exists" });
  } else {
    if (name && email && age && password && password_confirmation && address) {
      if (password === password_confirmation) {
        try {
          const sault = await bcrypt.genSalt(10);
          const hasPassword = await bcrypt.hash(password, sault);
          const doc = new User({
            name: name,
            email: email,
            age: age,
            password: hasPassword,
            address: address,
          });
          await doc.save();

          //Genrate Token
          // const save_user = await User.findOne({ email: email });
          // const token = jwt.sign({ userID: save_user._id },process.env.JWT_SECRET_KEY,{ expiresIn: "5d" });

          res.send({status: "success",  message: "User Registration Success"});
        } catch (error) {
          res.send({ status: "failed", message: "Unable to Register" });
        }
      } else {
        res.send({status: "failed",message: "Password and Confirm Password Does not match",});
      }
    } else {
      res.send({ status: "failed", message: "All filed Are" });
    }
  }
};

export default userRegistration;
