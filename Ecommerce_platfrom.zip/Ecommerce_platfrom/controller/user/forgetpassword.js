import User from "../../models/User.js";
import jwt from "jsonwebtoken";

//User Forget The Password
const forgetPassword = async (req, res) => {
  const { email } = req.body;
  if (email) {
    const user = await User.findOne({ email: email });
    if (user) {
      const secret = user._id + process.env.JWT_SECRET_KEY;
      const token = jwt.sign({ userID: user._id }, secret, {
        expiresIn: "15m",
      });
      const link = `http://localhost:5050/api/reset/${user._id}/${token}`;
      res.send({
        status: "success",
        message: "Password Reset Email Sent....Please Check Your Mail",
      });
      console.log(link);
    } else {
      res.send({ status: "failed", message: "Email Doesn't Exist" });
    }
  } else {
    res.send({ status: "failed", message: "Email Is Must Required" });
  }
};

export default forgetPassword;
