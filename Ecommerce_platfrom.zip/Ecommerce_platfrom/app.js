import 'dotenv/config'
import express from 'express'
import connectDB from './config/db.js'
import router from './routes/user.js'

const app = express()
const port = process.env.PORT
const DATABASE_URL = process.env.DATABASE_URL

connectDB(DATABASE_URL)

app.use(express.json())
app.use('/',router)

app.listen(port,()=>{
    console.log(`Server Running on Port ${port}`);
})
